import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  data :any={};
  isChatBox=false;
  constructor(private http:HttpClient) { 

  }
  private getData(res:Response)
  {
  let body = res;
  return body || {};
  }
  getUsers():Observable<any>
  {
    return this.http.get('https://jsonplaceholder.typicode.com/users').pipe(map(this.getData));
  }
  getUserData()
  {
    this.isChatBox==false?this.getUsers().subscribe(data=>{
        this.data =data;
        this.isChatBox= true;
        console.log("data"+JSON.stringify(data))
      }):this.isChatBox=false;
    
  }
}
